Hi Ali,

This is my assignment 3 for CPSC531.
I have few more extra java class files. One is the Pusdo-random generator Dr.Ghaderi sent us.
Others are Customer class, Batch Class, and some enum class represent the status of the customer.
Also, you may find the Assignment3_report_yuxi_wang.pdf file for the report.

Also, I used package to manage my assignments in this course. The way I compile my assignment
in command line is:
    1, Need to stay out side of assignment directory. For example, you are right out side of
        assignment_2 dir.
    2, Compile them "javac assignment_3/*.java"
    3, Run them: "java -cp ./ assignment_3.Tester"
Sorry for the inconvenience.

Thanks for reading,
Yuxi