package assignment_3;

/**
 * Created by Yuxibro on 15-11-09.
 */
public enum EventType{
    Arrival,LeaveToChef,LeaveSystem
}
