package assignment_3;

/**
 * Created by Yuxibro on 15-11-09.
 */
public enum CustomerStatus{
    Waiting,CashService,ChefService,LeftHappily, LeftCusImpatient, LeftCuzQueueFull,PreArrival
}
