Hi Ali,

This is my assignment 2 for CPSC531.
I have two extra java class files. One is the Pusdo-random generator Dr.Ghaderi sent us.
Another one is a Customer class I added for completing the assignment.

Also, I used package to manage my assignments in this course. The way I compile my assignment
in command line is:
    1, Need to stay out side of assignment directory. For example, you are right out side of
        assignment_2 dir.
    2, Compile them "javac assignment_2/*.java"
    3, Run them: "java -cp ./ assignment.Tester"
Sorry for the inconvenience. I use IDE very often.

Thanks for reading,
Yuxi